I included a jar file that you can just run via the linux console like:

$ java -jar PA_2b.jar

If that does not work, I guess you could make a java project in eclipse with a default package and try to run the Project.java.
I also included all the relevent source files so you can look at my code.